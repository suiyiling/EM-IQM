                                                                     
                                                                     
                                                                     
                                             
1. Place the files Pairwise_Alignment.m, DynamicProgrammingQ.c, smoker_urine.txt, and nonsmoker_urine.txt into the directory /home/MATLAB

2. Start MATLAb

3. Compile dynamic prgramming code by using the command >mex DynamicProgrammingQ.c

4. Run the code on the sample data by using the command >Pairwise_Alignment