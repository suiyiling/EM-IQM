Main Program with Description of Inputs and Outputs: GeodesicElasticClosed.m
Compile DynamicProgrammingQ.c in Matlab before using programs.